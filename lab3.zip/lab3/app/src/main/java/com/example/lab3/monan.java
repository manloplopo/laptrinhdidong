package com.example.lab3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class monan extends AppCompatActivity {

    ListView listView;
    ArrayList<MonAn> ds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bai8_1);

        listView = findViewById(R.id.listMonAn);

        ds = new ArrayList<>();
        ds.add(new MonAn("Hamburger", "Bánh mì kẹp thịt tròn", "65.000đ", R.drawable.hamburger));
        ds.add(new MonAn("Bánh mì", "Bánh mì thịt, chả", "15.000đ", R.drawable.banhmi));
        ds.add(new MonAn("Bánh bao", "Bánh bao nhân thịt", "12.000đ", R.drawable.banhbao));
        ds.add(new MonAn("Bánh giò", "Bánh giò nhân thịt", "10.000đ", R.drawable.banhgio));
        ds.add(new MonAn("Bánh gối", "Bánh gối chiên giòn", "8.000đ", R.drawable.banhu));

        listView.setAdapter(new MonAnAdapter());
    }

    // ===== MODEL =====
    class MonAn {
        String ten, mota, gia;
        int hinh;

        MonAn(String ten, String mota, String gia, int hinh) {
            this.ten = ten;
            this.mota = mota;
            this.gia = gia;
            this.hinh = hinh;
        }
    }

    // ===== ADAPTER =====
    class MonAnAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return ds.size();
        }

        @Override
        public Object getItem(int i) {
            return ds.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup parent) {

            LayoutInflater inflater = getLayoutInflater();
            View row = inflater.inflate(R.layout.item_monan, parent, false);

            ImageView imgHinh = row.findViewById(R.id.imgHinh);
            TextView txtTen = row.findViewById(R.id.txtTen);
            TextView txtMota = row.findViewById(R.id.txtMota);
            TextView txtGia = row.findViewById(R.id.txtGia);
            ImageView imgEdit = row.findViewById(R.id.imgEdit);
            ImageView imgDelete = row.findViewById(R.id.imgDelete);

            MonAn m = ds.get(i);

            imgHinh.setImageResource(m.hinh);
            txtTen.setText(m.ten);
            txtMota.setText(m.mota);
            txtGia.setText(m.gia);

            return row;
        }
    }
}
