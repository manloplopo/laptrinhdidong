package com.example.lab3;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class rgb extends AppCompatActivity {

    SeekBar seekR, seekG, seekB;
    TextView txtR, txtG, txtB;
    FrameLayout colorRGB, colorCMY;

    int r = 0, g = 0, b = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rgb);

        seekR = findViewById(R.id.seekR);
        seekG = findViewById(R.id.seekG);
        seekB = findViewById(R.id.seekB);

        txtR = findViewById(R.id.txtR);
        txtG = findViewById(R.id.txtG);
        txtB = findViewById(R.id.txtB);

        colorRGB = findViewById(R.id.colorRGB);
        colorCMY = findViewById(R.id.colorCMY);

        // Xử lý các SeekBar
        seekR.setOnSeekBarChangeListener(colorListener);
        seekG.setOnSeekBarChangeListener(colorListener);
        seekB.setOnSeekBarChangeListener(colorListener);
    }

    SeekBar.OnSeekBarChangeListener colorListener = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            if (seekBar == seekR) r = progress;
            if (seekBar == seekG) g = progress;
            if (seekBar == seekB) b = progress;

            txtR.setText("R = " + r);
            txtG.setText("G = " + g);
            txtB.setText("B = " + b);

            // RGB
            int rgbColor = Color.rgb(r, g, b);
            colorRGB.setBackgroundColor(rgbColor);

            // CMY colors (complement)
            int c = 255 - r;
            int m = 255 - g;
            int y = 255 - b;

            int cmyColor = Color.rgb(c, m, y);
            colorCMY.setBackgroundColor(cmyColor);
        }

        @Override public void onStartTrackingTouch(SeekBar seekBar) {}

        @Override public void onStopTrackingTouch(SeekBar seekBar) {}
    };
}
