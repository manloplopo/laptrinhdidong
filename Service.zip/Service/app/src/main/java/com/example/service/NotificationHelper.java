package com.example.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.RemoteViews;
import androidx.core.app.NotificationCompat;

public class NotificationHelper {
    private final Context ctx;
    private final NotificationManager nm;
    private final String CHANNEL_ID = "download_channel";

    public NotificationHelper(Context context) {
        this.ctx = context;
        nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        createChannel();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Download", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Thông báo download");
            nm.createNotificationChannel(ch);
        }
    }

    private int piFlags() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return flags;
    }

    public Notification buildNotification(int id, String title, int progress, boolean paused) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.notification_download);
        rv.setTextViewText(R.id.title, title != null ? title : "Downloading");
        if (progress >= 0) {
            rv.setTextViewText(R.id.progress_text, progress + "%");
            rv.setProgressBar(R.id.progress_bar, 100, progress, false);
        } else {
            rv.setTextViewText(R.id.progress_text, "");
            rv.setProgressBar(R.id.progress_bar, 100, 0, true);
        }

        String actPause = paused ? DownloadService.ACTION_RESUME : DownloadService.ACTION_PAUSE;
        Intent iPause = new Intent(ctx, DownloadReceiver.class).setAction(actPause);
        PendingIntent piPause = PendingIntent.getBroadcast(ctx, id, iPause, piFlags());

        Intent iCancel = new Intent(ctx, DownloadReceiver.class).setAction(DownloadService.ACTION_CANCEL);
        PendingIntent piCancel = PendingIntent.getBroadcast(ctx, id + 1, iCancel, piFlags());

        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setCustomContentView(rv)
                .setOnlyAlertOnce(true)
                .setOngoing(!paused)
                .addAction(android.R.drawable.ic_media_pause, paused ? "Resume" : "Pause", piPause)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", piCancel);

        return b.build();
    }

    public void updateNotification(int id, String title, int progress, boolean paused) {
        nm.notify(id, buildNotification(id, title, progress, paused));
    }

    public void showCompleted(int id, String filename) {
        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Hoàn tất")
                .setContentText(filename)
                .setAutoCancel(true);
        nm.notify(id, b.build());
    }
}
