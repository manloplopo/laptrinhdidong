package com.example.lab1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class Xucxac extends AppCompatActivity {

    private TextView txtDiceNumber;
    private ImageView imgDice;
    private Button btnRoll;

    private final Random randomGenerator = new Random();

    // Mảng chứa ID hình ảnh cho 6 mặt xúc xắc
    private final int[] diceImages = {
            R.drawable.dice_1,
            R.drawable.dice_2,
            R.drawable.dice_3,
            R.drawable.dice_4,
            R.drawable.dice_5,
            R.drawable.dice_6
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.trangxucxac);

        // Ánh xạ các control
        txtDiceNumber = findViewById(R.id.txtDiceNumber);
        imgDice = findViewById(R.id.imgDice);
        btnRoll = findViewById(R.id.btnRoll);

        // Thiết lập sự kiện cho nút "Tung Xúc Xắc"
        btnRoll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rollDice();
            }
        });
    }

    private void rollDice() {
        // 1. Tạo số ngẫu nhiên từ 1 đến 6
        int diceResult = randomGenerator.nextInt(6) + 1;

        // 2. Cập nhật TextView hiển thị số xúc xắc
        txtDiceNumber.setText(String.valueOf(diceResult));

        // 3. Cập nhật hình xúc xắc tương ứng
        int imageResourceId = diceImages[diceResult - 1];
        imgDice.setImageResource(imageResourceId);
    }
}
