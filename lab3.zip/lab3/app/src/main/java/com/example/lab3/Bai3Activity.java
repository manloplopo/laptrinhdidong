package com.example.lab3;

import android.app.Dialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class Bai3Activity extends AppCompatActivity {

    Button btnToast, btnDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bai7);

        btnToast = findViewById(R.id.btnToast);
        btnDialog = findViewById(R.id.btnDialog);

        // ===== CUSTOM TOAST =====
        btnToast.setOnClickListener(v -> showCustomToast());

        // ===== CUSTOM DIALOG =====
        btnDialog.setOnClickListener(v -> showLoginDialog());
    }

    // ---------------- CUSTOM TOAST ----------------
    private void showCustomToast() {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast, null);

        TextView txt = layout.findViewById(R.id.txtToastMsg);
        txt.setText("Custom Toast, made by Duy Quy");

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL, 0, 200);
        toast.setView(layout);
        toast.show();
    }

    // ---------------- CUSTOM DIALOG ----------------
    private void showLoginDialog() {
        Dialog dialog = new Dialog(Bai3Activity.this);
        dialog.setContentView(R.layout.dialog_login);

        EditText txtUser = dialog.findViewById(R.id.txtUser);
        EditText txtPass = dialog.findViewById(R.id.txtPass);
        Button btnOK = dialog.findViewById(R.id.btnOK);
        Button btnCancel = dialog.findViewById(R.id.btnCancel);

        btnOK.setOnClickListener(v -> {
            String u = txtUser.getText().toString().trim();
            String p = txtPass.getText().toString().trim();

            if (u.equals("admin") && p.equals("123")) {
                showSuccessToast("Đăng nhập thành công!");
                dialog.dismiss();
            } else {
                showSuccessToast("Sai tài khoản hoặc mật khẩu!");
            }
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    // Toast tái sử dụng
    private void showSuccessToast(String message) {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast, null);

        TextView txt = layout.findViewById(R.id.txtToastMsg);
        txt.setText(message);

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL, 0, 200);
        toast.setView(layout);
        toast.show();
    }
}
