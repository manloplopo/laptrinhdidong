package com.example.multithreading;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private ProgressBar pbFirst, pbSecond, pbWaiting;
    private TextView tvMsgWorking, tvMsgReturned, tvTopCaption;
    private Button btnStart, btnExecute;
    private EditText etInput;

    private Handler handler;
    private Thread bgThread;
    private boolean isRunning;
    private int MAX_SEC, intTest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewByIds();
        initVariables();

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isRunning = true;
                pbFirst.setVisibility(View.VISIBLE);
                pbSecond.setVisibility(View.VISIBLE);
                btnStart.setVisibility(View.GONE);
                tvMsgReturned.setText("");
                tvMsgWorking.setText(getString(R.string.working) + " 0");

                // Bắt đầu thread nền
                if (bgThread == null || !bgThread.isAlive()) {
                    initBgThread();
                    bgThread.start();
                }
            }
        });

        // Lab-Post: chỉ để minh họa, không dùng trong bài
        btnExecute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = etInput.getText().toString();
                Toast.makeText(MainActivity.this, input, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void findViewByIds() {
        pbFirst = findViewById(R.id.pb_first);
        pbSecond = findViewById(R.id.pb_second);
        tvMsgWorking = findViewById(R.id.tv_working);
        tvMsgReturned = findViewById(R.id.tv_return);
        btnStart = findViewById(R.id.btn_start);

        // Lab-Post views (nếu layout có)
        tvTopCaption = findViewById(R.id.tv_top_caption);
        pbWaiting = findViewById(R.id.pb_waiting);
        etInput = findViewById(R.id.et_input);
        btnExecute = findViewById(R.id.btn_execute);

        // Fail fast nếu view bị thiếu — giúp xác định lỗi layout ngay lập tức
        StringBuilder missing = new StringBuilder();
        if (pbFirst == null) missing.append(" pb_first");
        if (pbSecond == null) missing.append(" pb_second");
        if (tvMsgWorking == null) missing.append(" tv_working");
        if (tvMsgReturned == null) missing.append(" tv_return");
        if (btnStart == null) missing.append(" btn_start");
        if (missing.length() > 0) {
            throw new IllegalStateException("Missing view ids in layout:" + missing.toString() + ". Check app/src/main/res/layout/activity_main.xml");
        }
    }

    private void initVariables() {
        isRunning = false;
        MAX_SEC = 20;
        intTest = 1;

        // bảo đảm pbFirst không null trước khi dùng
        if (pbFirst == null) {
            throw new IllegalStateException("pbFirst is null. Did you call findViewByIds() after setContentView(...) and does activity_main.xml contain @id/pb_first?");
        }

        pbFirst.setMax(MAX_SEC);
        pbFirst.setProgress(0);
        pbFirst.setVisibility(View.GONE);

        if (pbSecond != null) pbSecond.setVisibility(View.GONE);

        // Handler và handleMessage phải ở đây (không trong findViewByIds)
        handler = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                // đảm bảo msg.obj không null và là String
                Object o = msg.obj;
                String returnedValue = o != null ? String.valueOf(o) : "";
                tvMsgReturned.setText(getString(R.string.returned_by_bg_thread) + returnedValue);

                // cập nhật progress
                pbFirst.incrementProgressBy(2);
                if (pbFirst.getProgress() >= MAX_SEC) {
                    tvMsgReturned.setText(getString(R.string.done_background_thread_has_been_stopped));
                    tvMsgWorking.setText(getString(R.string.done));
                    pbFirst.setVisibility(View.GONE);
                    pbSecond.setVisibility(View.GONE);
                    btnStart.setVisibility(View.VISIBLE);
                    isRunning = false;
                } else {
                    tvMsgWorking.setText(getString(R.string.working) + " " + pbFirst.getProgress());
                }
            }
        };
    }

    private void initBgThread() {
        // Tạo mới Random trong thread nền; không dùng new Random() trong handler
        bgThread = new Thread(new Runnable() {
            @Override
            public void run() {
                Random rnd = new Random();
                try {
                    for (int i = 0; i < MAX_SEC && isRunning; i++) {
                        Thread.sleep(1000);

                        // Sinh random trong bg thread và gửi Message
                        String data = "Thread value: " + rnd.nextInt(101);
                        data += getString(R.string.global_value_seen) + " " + intTest;
                        intTest++;

                        if (isRunning && handler != null) {
                            Message m = handler.obtainMessage(1, data);
                            handler.sendMessage(m);
                        }
                    }
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                } catch (Throwable t) {
                    Log.e("initBgThread", "bg thread error", t);
                }
            }
        });
    }
}