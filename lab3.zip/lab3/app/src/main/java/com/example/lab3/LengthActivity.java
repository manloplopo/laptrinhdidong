package com.example.lab3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.*;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;

import com.google.android.material.appbar.MaterialToolbar;

import org.jspecify.annotations.NonNull;


public class LengthActivity extends AppCompatActivity {

    EditText txtNumber;
    Spinner spnUnit;
    ListView listViewLength;

    // Tên đơn vị
    String[] unitNames = {
            "Hải lý", "Dặm", "Kilometer", "Lý",
            "Met", "Yard", "Foot", "Inches"
    };

    // MA TRẬN TỈ LỆ (8×8)
    double[][] rate = {
            {1.0, 1.15077945, 1.852, 20.2537183, 1852, 2025.37183, 6076.11549, 72913.38583},
            {0.86897624, 1.0, 1.609344, 17.60, 1609.344, 1760.0, 5280.0, 63360},
            {0.53995680, 0.62137119, 1.0, 10.9361330, 1000.0, 1093.61330, 3280.83990, 39370.07874},
            {0.04937365, 0.05681818, 0.0914400, 1.0000, 91.44, 100.0, 300.0, 3600.0},
            {0.00053996, 0.00062137, 0.0010000, 0.0109361, 1.0, 1.09361, 3.28084, 39.37008},
            {0.00049374, 0.00056818, 0.0009440, 0.01000, 0.9144, 1.0, 3.0, 36.0},
            {0.00016458, 0.00018939, 0.00030843, 0.0033333, 0.3048, 0.33333, 1.0, 12.0},
            {0.00001371, 0.00001578, 0.0000254, 0.0002778, 0.0254, 0.02778, 0.08333, 1.0}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_length);

        txtNumber = findViewById(R.id.txtNumber);
        spnUnit = findViewById(R.id.spnUnit);
        listViewLength = findViewById(R.id.listViewLength);

        // Spinner
        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, unitNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnUnit.setAdapter(adapter);

        txtNumber.addTextChangedListener(textWatcher);
        spnUnit.setOnItemSelectedListener(spListener);

        updateList();
        MaterialToolbar topAppBar = findViewById(R.id.topAppBar);
        setSupportActionBar(topAppBar);

    }

    TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            updateList();
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    AdapterView.OnItemSelectedListener spListener = new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, android.view.View view, int pos, long id) {
            updateList();
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
        }
    };

    void updateList() {
        double val = 0;
        try {
            val = Double.parseDouble(txtNumber.getText().toString());
        } catch (Exception ignored) {
        }

        int from = spnUnit.getSelectedItemPosition();

        double[] results = new double[unitNames.length];
        for (int i = 0; i < results.length; i++) {
            results[i] = val * rate[from][i];
        }

        LengthAdapter adapter = new LengthAdapter(this, unitNames, results);
        listViewLength.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_money) {
            startActivity(new Intent(LengthActivity.this, MainActivity.class));
            return true;
        }

        if (id == R.id.menu_length) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



}
