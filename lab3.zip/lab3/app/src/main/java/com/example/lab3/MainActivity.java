package com.example.lab3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.*;
import android.widget.*;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;

import com.google.android.material.appbar.MaterialToolbar;

import org.jspecify.annotations.NonNull;


public class MainActivity extends AppCompatActivity {

    EditText txtNumber;
    Spinner spnUnit;
    ListView listViewRate;

    String[] codes = {"USD", "EUR", "GBP", "INR", "AUD", "CAD", "ZAR", "NZD", "JPY"};

    int[] flags = {
            R.drawable.america,
            R.drawable.eu,
            R.drawable.england,
            R.drawable.india,
            R.drawable.australia,
            R.drawable.canada,
            R.drawable.southafrica,
            R.drawable.newzealand,
            R.drawable.japan
    };

    double[][] rate = {
            {1, 0.91, 0.79, 83, 1.48, 1.36, 18.30, 1.64, 148},
            {1.09, 1, 0.86, 92, 1.62, 1.48, 20.10, 1.78, 162},
            {1.27, 1.16, 1, 105, 1.88, 1.71, 23, 2.10, 185},
            {0.012, 0.011, 0.0095, 1, 0.018, 0.016, 0.22, 0.019, 1.76},
            {0.68, 0.62, 0.53, 56, 1, 0.91, 12, 1.12, 98},
            {0.73, 0.67, 0.58, 60, 1.10, 1, 13.1, 1.20, 103},
            {0.055, 0.049, 0.043, 4.6, 0.083, 0.076, 1, 0.092, 8.3},
            {0.61, 0.56, 0.48, 52, 0.89, 0.83, 10.8, 1, 92},
            {0.0068, 0.0061, 0.0054, 0.57, 0.010, 0.0096, 0.12, 0.010, 1}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtNumber = findViewById(R.id.txtNumber);
        spnUnit = findViewById(R.id.spnUnit);
        listViewRate = findViewById(R.id.listViewRate);

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, codes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnUnit.setAdapter(adapter);

        txtNumber.addTextChangedListener(textWatcher);
        spnUnit.setOnItemSelectedListener(spinnerListener);

        updateList();

        MaterialToolbar topAppBar = findViewById(R.id.topAppBar);
        setSupportActionBar(topAppBar);

    }

    TextWatcher textWatcher = new TextWatcher() {
        @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
            updateList();
        }
        @Override public void afterTextChanged(Editable s) {}
    };

    AdapterView.OnItemSelectedListener spinnerListener = new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
            updateList();
        }
        @Override public void onNothingSelected(AdapterView<?> parent) {}
    };


    void updateList() {
        double val = 0;
        try {
            val = Double.parseDouble(txtNumber.getText().toString());
        } catch (Exception e) {}

        int from = spnUnit.getSelectedItemPosition();

        double[] results = new double[codes.length];
        for (int i = 0; i < results.length; i++) {
            results[i] = val * rate[from][i];
        }

        CurrencyAdapter adapter = new CurrencyAdapter(this, flags, codes, results);
        listViewRate.setAdapter(adapter);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_money) {
            return true;
        }

        if (id == R.id.menu_length) {
            startActivity(new Intent(MainActivity.this, LengthActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



}
