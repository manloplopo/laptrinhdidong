package com.example.service;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import androidx.annotation.Nullable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownloadService extends Service {
    public static final String ACTION_START = "com.example.service.action.START";
    public static final String ACTION_PAUSE = "com.example.service.action.PAUSE";
    public static final String ACTION_RESUME = "com.example.service.action.RESUME";
    public static final String ACTION_CANCEL = "com.example.service.action.CANCEL";
    public static final String EXTRA_URL = "extra_url";
    public static final String EXTRA_FILENAME = "extra_filename";
    public static final int NOTIF_ID = 1001;

    private volatile boolean isPaused = false;
    private volatile boolean isCanceled = false;
    private final Object pauseLock = new Object();
    private Thread downloadThread;

    private NotificationHelper notifHelper;

    @Override
    public void onCreate() {
        super.onCreate();
        notifHelper = new NotificationHelper(this);
    }

    @SuppressLint("ForegroundServiceType")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_START.equals(action)) {
            String url = intent.getStringExtra(EXTRA_URL);
            String filename = intent.getStringExtra(EXTRA_FILENAME);
            startForeground(NOTIF_ID, notifHelper.buildNotification(NOTIF_ID, filename != null ? filename : "download", 0, false));
            startDownload(url, filename);
        } else if (ACTION_PAUSE.equals(action)) {
            isPaused = true;
            notifHelper.updateNotification(NOTIF_ID, "Tạm dừng", -1, true);
        } else if (ACTION_RESUME.equals(action)) {
            isPaused = false;
            synchronized (pauseLock) { pauseLock.notifyAll(); }
            notifHelper.updateNotification(NOTIF_ID, "Tiếp tục", -1, false);
        } else if (ACTION_CANCEL.equals(action)) {
            isCanceled = true;
            if (downloadThread != null) downloadThread.interrupt();
            stopForeground(true);
            stopSelf();
        }
        return START_STICKY;
    }

    private void startDownload(final String fileUrl, final String fileName) {
        if (downloadThread != null && downloadThread.isAlive()) return;
        isPaused = false;
        isCanceled = false;

        downloadThread = new Thread(() -> {
            HttpURLConnection conn = null;
            InputStream in = null;
            FileOutputStream fos = null;
            try {
                URL url = new URL(fileUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(15_000);
                conn.setReadTimeout(15_000);
                conn.connect();

                int code = conn.getResponseCode();
                if (code != HttpURLConnection.HTTP_OK) {
                    Log.e("DownloadService", "HTTP error: " + code);
                    return;
                }
                int total = Math.max(1, conn.getContentLength());
                in = conn.getInputStream();

                File out = new File(getFilesDir(), fileName != null ? fileName : "download.bin");
                fos = new FileOutputStream(out);

                byte[] buf = new byte[8 * 1024];
                int read;
                long downloaded = 0;
                while ((read = in.read(buf)) != -1) {
                    if (isCanceled) {
                        try { fos.close(); } catch (Exception ignored) {}
                        out.delete();
                        return;
                    }
                    if (isPaused) {
                        synchronized (pauseLock) {
                            while (isPaused && !isCanceled) {
                                pauseLock.wait();
                            }
                        }
                    }
                    fos.write(buf, 0, read);
                    downloaded += read;
                    int progress = (int) ((downloaded * 100L) / total);
                    notifHelper.updateNotification(NOTIF_ID, "Đang tải...", progress, false);
                }
                fos.flush();
                notifHelper.showCompleted(NOTIF_ID, out.getName());
            } catch (Exception e) {
                Log.e("DownloadService", "Download failed", e);
                notifHelper.updateNotification(NOTIF_ID, "Lỗi", -1, false);
            } finally {
                try { if (in != null) in.close(); } catch (Exception ignored) {}
                try { if (fos != null) fos.close(); } catch (Exception ignored) {}
                try { if (conn != null) conn.disconnect(); } catch (Exception ignored) {}
                stopForeground(true);
                stopSelf();
            }
        }, "download-thread");
        downloadThread.start();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }
}
