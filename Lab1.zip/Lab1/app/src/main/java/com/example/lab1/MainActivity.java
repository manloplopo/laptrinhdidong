package com.example.lab1;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText txtX, txtY;
    private TextView txtResult;
    private Button btnPlus, btnMinus, btnMul, btnDiv, btnMod;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Làm cho giao diện tràn viền và nằm sát dưới camera
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(0, 0, 0, 0); // loại bỏ padding mặc định
            return insets;
        });

        initControl();
    }

    private void initControl() {
        txtX = findViewById(R.id.txtX);
        txtY = findViewById(R.id.txtY);
        txtResult = findViewById(R.id.txtResult);

        btnPlus = findViewById(R.id.btnPlus);
        btnMinus = findViewById(R.id.btnMinus);
        btnMul = findViewById(R.id.btnMultiply);
        btnDiv = findViewById(R.id.btnDivide);
        btnMod = findViewById(R.id.btnModulus);

        // Tạo 1 listener chung cho 5 nút
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    double x = Double.parseDouble(txtX.getText().toString());
                    double y = Double.parseDouble(txtY.getText().toString());
                    double result = 0;

                    int id = view.getId();

                    if (id == R.id.btnPlus) {
                        result = x + y;
                    } else if (id == R.id.btnMinus) {
                        result = x - y;
                    } else if (id == R.id.btnMultiply) {
                        result = x * y;
                    } else if (id == R.id.btnDivide) {
                        if (y == 0) {
                            txtResult.setText("Lỗi chia 0");
                            return;
                        }
                        result = x / y;
                    } else if (id == R.id.btnModulus) {
                        if (y == 0) {
                            txtResult.setText("Lỗi chia 0");
                            return;
                        }
                        result = x % y;
                    }

                    txtResult.setText(String.valueOf(result));

                } catch (NumberFormatException e) {
                    txtResult.setText("Lỗi nhập số");
                }
            }
        };

        // Gắn sự kiện cho nút
        btnPlus.setOnClickListener(listener);
        btnMinus.setOnClickListener(listener);
        btnMul.setOnClickListener(listener);
        btnDiv.setOnClickListener(listener);
        btnMod.setOnClickListener(listener);
    }
}
