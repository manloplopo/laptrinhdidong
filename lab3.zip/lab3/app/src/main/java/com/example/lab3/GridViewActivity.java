package com.example.lab3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

public class GridViewActivity extends AppCompatActivity {

    GridView gridView;

    // DATA
    String[] names = {
            "Maboo", "SameOldShawn", "Magnitude901",
            "Brandon", "Clement_RGF", "Nebja",
            "BBDS", "PleaseDe-ModMe", "DLizzle",
            "palaceeight", "TheDarkKnight", "hellrel"
    };

    String[] scores = {
            "283,297", "252,433", "164,935",
            "100,466", "93,932", "84,187",
            "81,762", "79,243", "76,331",
            "75,497", "69,138", "68,903"
    };

    int[] avatars = {
            R.drawable.img1, R.drawable.img2, R.drawable.img3,
            R.drawable.img4, R.drawable.img5, R.drawable.img6,
            R.drawable.img7, R.drawable.img8, R.drawable.img9,
            R.drawable.img10, R.drawable.img11, R.drawable.img12
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gridview);

        gridView = findViewById(R.id.gridView);
        gridView.setAdapter(new ContributorAdapter());
    }

    // ===================== ADAPTER =====================
    class ContributorAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return names.length;
        }

        @Override
        public Object getItem(int position) {
            return names[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int i, View convertView, ViewGroup parent) {

            View row;

            if (convertView == null) {
                LayoutInflater inflater = getLayoutInflater();
                row = inflater.inflate(R.layout.item_contributor, parent, false);
            } else {
                row = convertView;
            }

            ImageView imgAvatar = row.findViewById(R.id.imgAvatar);
            TextView txtName = row.findViewById(R.id.txtName);
            TextView txtScore = row.findViewById(R.id.txtScore);

            imgAvatar.setImageResource(avatars[i]);
            txtName.setText(names[i]);
            txtScore.setText(scores[i]);

            return row;
        }
    }
}
