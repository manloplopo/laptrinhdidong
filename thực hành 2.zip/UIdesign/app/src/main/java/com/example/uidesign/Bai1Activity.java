package com.example.uidesign;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class Bai1Activity extends AppCompatActivity {

    int[] colors = {
            0xFFFFCDD2, 0xFFC8E6C9, 0xFFBBDEFB, 0xFFFFF9C4, 0xFFD1C4E9
    };

    int[] icons = {
            R.drawable.img_1,
            R.drawable.img_3,
            R.drawable.img_4,
            R.drawable.favourite,
            R.drawable.img
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai1);

        LinearLayout layout = findViewById(R.id.layoutBai1);
        ImageView imageView = findViewById(R.id.random_icon);

        Random random = new Random();
        int color = colors[random.nextInt(colors.length)];
        int icon = icons[random.nextInt(icons.length)];

        layout.setBackgroundColor(color);
        imageView.setImageResource(icon);
    }
}
