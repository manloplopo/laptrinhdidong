package com.example.lab3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;

public class HomeActivity extends AppCompatActivity {

    Button btnMoney, btnLength, btnBai3,btnBai4,btnmonan ,btngridview,btnExit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btnMoney = findViewById(R.id.btnMoney);
        btnLength = findViewById(R.id.btnLength);
        btnBai3 = findViewById(R.id.btnBai3);
        btnBai4 = findViewById(R.id.btnBai4);
        btnmonan = findViewById(R.id.btnmonan);
        btngridview = findViewById(R.id.btnGridView);
        btnExit = findViewById(R.id.btnExit);

        // Bài 1: Đổi tiền
        btnMoney.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, MainActivity.class))
        );

        // Bài 2: Đổi độ dài
        btnLength.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, LengthActivity.class))
        );

        // Bài 3: RGB – CMY Seekbar
        btnBai3.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, Bai3Activity.class))
        );
        btnBai4.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, rgb.class))
        );
        btnmonan.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, monan.class))
        );

        btngridview.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, GridViewActivity.class))
        );



        // Thoát app
        btnExit.setOnClickListener(v -> finishAffinity());
    }
}
