package com.example.uidesign;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;

public class M000SplashFrg extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.m003_act_detail, container, false);
        initViews();
        return view;
    }

    private void initViews() {
        // Sau 2 giây sẽ chuyển sang M001 screen
        new Handler().postDelayed(this::gotoM001Screen, 2000);
    }

    private void gotoM001Screen() {
        if (getActivity() instanceof DemoMainActivity) {
            ((DemoMainActivity) getActivity()).gotoM001Screen();
        }
    }
}
