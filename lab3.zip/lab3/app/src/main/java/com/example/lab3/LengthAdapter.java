package com.example.lab3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;


public class LengthAdapter extends ArrayAdapter<String> {

    private Context context;
    private String[] unitNames;
    private double[] values;

    public LengthAdapter(@NonNull Context context, String[] unitNames, double[] values) {
        super(context, R.layout.row_length, unitNames);
        this.context = context;
        this.unitNames = unitNames;
        this.values = values;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.row_length, parent, false);
        }

        TextView txtValue = convertView.findViewById(R.id.txtValue);
        TextView txtUnit = convertView.findViewById(R.id.txtUnit);

        txtValue.setText(String.format("%.4f", values[position]));
        txtUnit.setText(unitNames[position]);

        return convertView;
    }

}
