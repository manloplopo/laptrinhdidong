package com.example.lab1;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Trangchu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.trangchu);

        Button btnBai1 = findViewById(R.id.btnBai1Calculator);
        Button btnBai2 = findViewById(R.id.btnBai2DiceRoller);
        Button btnBai3 = findViewById(R.id.btnBai3CallSms);


        // Chuyển sang Bài 1: Máy tính
        btnBai1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Trangchu.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Chuyển sang Bài 2: Tung Xúc Xắc
        btnBai2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Trangchu.this, Xucxac.class);
                startActivity(intent);
            }
        });

        btnBai3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Trangchu.this, Goidien.class);
                startActivity(intent);
            }
        });

    }
}
