package com.example.uidesign;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn1 = findViewById(R.id.btnBai1);
        Button btn2 = findViewById(R.id.btnBai2);
        Button btn3 = findViewById(R.id.btnBai3);

        btn1.setOnClickListener(v -> startActivity(new Intent(this, Bai1Activity.class)));
        btn2.setOnClickListener(v -> startActivity(new Intent(this, Bai2Activity.class)));
        btn3.setOnClickListener(v -> startActivity(new Intent(this, Bai3Activity.class)));
    }
}
