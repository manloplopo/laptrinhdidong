package com.example.uidesign;

import java.io.Serializable;

public class StoryEntity implements Serializable {
    private String title;
    private String content;

    public StoryEntity(String title, String content) {
        this.title = title;
        this.content = content;
    }

    // Getter và Setter
    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
