package com.example.lab3;

import android.content.Context;
import android.view.*;
import android.widget.*;

public class CurrencyAdapter extends BaseAdapter {

    Context context;
    int[] flags;
    String[] codes;
    double[] values;

    LayoutInflater inflater;

    public CurrencyAdapter(Context context, int[] flags, String[] codes, double[] values) {
        this.context = context;
        this.flags = flags;
        this.codes = codes;
        this.values = values;

        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return codes.length;
    }

    @Override
    public Object getItem(int i) {
        return codes[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.item_currency, null);

        ImageView img = convertView.findViewById(R.id.imgFlag);
        TextView txtCode = convertView.findViewById(R.id.txtCode);
        TextView txtValue = convertView.findViewById(R.id.txtValue);

        img.setImageResource(flags[i]);
        txtCode.setText(codes[i]);
        txtValue.setText(String.format("%.5f", values[i]));

        return convertView;
    }

}
